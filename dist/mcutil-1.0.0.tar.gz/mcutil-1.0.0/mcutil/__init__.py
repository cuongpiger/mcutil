__version__ = "1.0.0"

from .printer import cprint
